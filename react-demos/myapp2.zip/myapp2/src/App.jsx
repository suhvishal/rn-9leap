import './App.css';
import Movies from './Components/Movies';

function App() {
  return (
    <div className='container'>
      
      <Movies />

    </div>
  );
}

export default App;
