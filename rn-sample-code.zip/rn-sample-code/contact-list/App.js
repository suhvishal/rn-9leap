import React from 'react';

import AppContainer from './routes';

export default function App() {
  return <AppContainer />;
}
