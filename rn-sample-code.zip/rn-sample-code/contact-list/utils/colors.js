export default {
  blue: '#3498DB',
  greyLight: '#f7f7f7',
  grey: '#D8D8D8',
  greyDark: '#BBBBBB',
  black: '#000000',
};
